## v0.6.2 — 2026-03-22
- fix: inject script content via func arg instead of files, bypasses tab state issues

## v0.6.1 — 2026-03-22
- fix: content script triggers SW injection on load, not just tab navigation

# Changelog

## v0.5.6 — 2026-03-22
- Fixed SW registration failure (lazy vector backend import)
- Fixed triple-quote and curly-quote syntax errors

## v0.5.5 — 2026-03-22
- Added ⚡CI Intelligence tab to HUD
- Live injection stream (SHARD/RAG layers per turn)
- § Symbol Dictionary grows with pattern recognition
- Compression event cards showing tokens saved

## v0.5.2
- Tier 1 context injection on every claude.ai message
- HUD Tokens + Captures tabs
