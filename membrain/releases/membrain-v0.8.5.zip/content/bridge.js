﻿/**
 * MemBrain â€" Content Script Bridge (v0.5.5)
 *
 * Injection order: interceptor.js â†' compression.js â†' synapse.js
 * Call order when fetch() fires: synapse â†' compression â†' interceptor â†' original fetch
 */

(function () {
  'use strict';

  const PREFIX = 'memory-ext';

  function injectScript(src, onload, onerror) {
    // Injection handled by service worker via chrome.scripting.executeScript (MAIN world)
    // This bypasses page CSP. bridge.js just coordinates messaging.
    if (onload) setTimeout(onload, 100); // signal ready after SW injection
  }

  function injectAll() {
    // interceptor + compression injected via src (work fine on all platforms)
    // synapse is injected by service worker via chrome.scripting (world: MAIN) to bypass CSP
    injectScript(
      'interceptor/interceptor.js',
      () => {
        injectScript(
          'interceptor/compression.js',
          () => {
            console.debug('[MemBrain] Page scripts injected (interceptor + compression)');
            // Also inject context-inject.js for Helix CI/context injection
            injectScript(
              'interceptor/context-inject.js',
              () => console.debug('[MemBrain] context-inject.js loaded'),
              () => console.warn('[MemBrain] context-inject.js failed to load'),
            );
          },
          () => console.warn('[MemBrain] compression.js failed to load'),
        );
      },
      () => console.error('[MemBrain] interceptor.js failed to inject'),
    );
  }

  function setupInputRelay() {
    window.addEventListener('message', async (event) => {
      if (event.source !== window) return;
      if (!event.data || event.data.source !== PREFIX) return;

      const { type, payload } = event.data;
      console.debug('[MemBrain:bridge] received message:', type);

      // Tier 1 async relay â€" needs round-trip response
      if (type === `${PREFIX}:tier1-request`) {
        const { session_id, query, budget, nonce } = payload || {};
        if (!session_id || !query || !nonce) return;

        try {
          const result = await chrome.runtime.sendMessage({
            action: 'tier1-request',
            data: { session_id, query, budget: budget || 1000 },
          });
          window.postMessage({
            source: PREFIX,
            type: `${PREFIX}:tier1-response-${nonce}`,
            payload: {
              injection_text: result?.injection_text || null,
              tokens_used: result?.tokens_used || 0,
            },
          }, '*');
        } catch {
          window.postMessage({
            source: PREFIX,
            type: `${PREFIX}:tier1-response-${nonce}`,
            payload: { injection_text: null },
          }, '*');
        }
        return;
      }

      let action = null;
      let data = payload;

      switch (type) {
        case `${PREFIX}:stream-complete`:
        case `${PREFIX}:response-captured`:
          action = 'conversation-turn';
          data = { ...payload, captureType: type === `${PREFIX}:stream-complete` ? 'stream' : 'response', tabUrl: window.location.href };
          break;
        case `${PREFIX}:request-captured`:
          action = 'request-outgoing';
          data = { ...payload, tabUrl: window.location.href };
          break;
        case `${PREFIX}:interceptor-ready`:
          action = 'interceptor-status';
          data = { ...payload, status: 'ready', tabUrl: window.location.href };
          break;
        case `${PREFIX}:stream-error`:
          action = 'error-report';
          data = { ...payload, tabUrl: window.location.href };
          break;
        case `${PREFIX}:injection-applied`:
          action = 'injection-applied';
          data = { ...payload, tabUrl: window.location.href };
          break;
        case `${PREFIX}:token-usage`:
          action = 'token-usage';
          data = { ...payload, tabUrl: window.location.href };
          break;
        case `${PREFIX}:context-injected`:
          action = 'context-injected';
          data = { ...payload };
          break;
        default:
          return;
      }

      if (!action) return;
      try { chrome.runtime.sendMessage({ action, data }).catch(() => {}); } catch {}
    });
  }

  function setupOutputRelay() {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (!msg) return false;

      if (msg._membrainBusEvent === true) {
        switch (msg.event) {
          case 'injection.ready':
            window.postMessage({ source: PREFIX, type: `${PREFIX}:injection-update`, payload: msg.payload }, '*');
            // Also send current storage mode so MAIN world context-inject.js knows
            chrome.storage.session.get('mb_storage_mode').then(r => {
              const mode = r.mb_storage_mode || 'local';
              window.postMessage({ source: PREFIX, type: `${PREFIX}:storage-mode`, payload: { mode } }, '*');
            }).catch(() => {});
            break;
          case 'synapse.ready':
            window.postMessage({ source: PREFIX, type: `${PREFIX}:synapse-toggle`, payload: { enabled: true } }, '*');
            window.postMessage({ source: PREFIX, type: `${PREFIX}:compression-toggle`, payload: { enabled: true } }, '*');
            break;
          case 'hud.update':
            window.postMessage({ source: PREFIX, type: `${PREFIX}:hud-update`, payload: msg.payload }, '*');
            break;

          case 'dictionary.update':
            // Push shorthand map to compression.js in page world
            window.postMessage({ source: PREFIX, type: `${PREFIX}:dictionary-update`, payload: msg.payload }, '*');
            break;
        }
        sendResponse({ relayed: true });
        return false;
      }

      switch (msg.action) {
        case 'context-inject-toggle':
          window.postMessage({ source: PREFIX, type: `${PREFIX}:context-inject-toggle`, payload: { enabled: msg.enabled } }, '*');
          sendResponse({ ok: true });
          return false;
        case 'synapse-toggle':
          window.postMessage({ source: PREFIX, type: `${PREFIX}:synapse-toggle`, payload: { enabled: msg.enabled } }, '*');
          sendResponse({ ok: true });
          return false;
        case 'expander-toggle':
          window.postMessage({ source: PREFIX, type: `${PREFIX}:expander-toggle`, payload: { enabled: msg.enabled } }, '*');
          sendResponse({ ok: true });
          return false;
        case 'refresh-injection':
          refreshInjectionCache();
          sendResponse({ ok: true });
          return false;
      }

      return false;
    });
  }

  async function refreshInjectionCache(userMessage) {
    try {
      const response = await chrome.runtime.sendMessage({ action: 'get-injection', data: { userMessage: userMessage || '' } });
      if (response) {
        window.postMessage({ source: PREFIX, type: `${PREFIX}:injection-update`, payload: response }, '*');
      }
    } catch {}
  }

  function setupBubbleSanitizer() {
    const SPEC_START = '--- CMPRS ---';
    const MB_CTX_START = '[MEMBRAIN CONTEXT]';
    const MB_CTX_END = '[END MEMBRAIN CONTEXT]';
    const SPEC_END = '--- END ---';
    const CTX_START = '<helix_context>';
    const CTX_END = '</helix_context>';
    const USER_MSG_SELECTORS = ['[data-testid="user-message"]', '.human-turn', '[class*="user-message"]', '[class*="HumanTurn"]'];

    function sanitize(container) {
      if (!container) return;
      const txt = container.textContent || '';
      const hasMB = txt.includes(MB_CTX_START);
      const hasCmprs = txt.includes(SPEC_START);
      const hasCtx = txt.includes(CTX_START);
      if (!hasMB && !hasCmprs && !hasCtx) return;

      // Walk ALL descendant text nodes and hide elements containing our markers
      const allEls = Array.from(container.querySelectorAll('*'));
      let hiding = false, hiding2 = false, hiding3 = false;

      for (const el of allEls) {
        const t = el.textContent.trim();
        // Start hiding
        if (!hiding && t.includes(SPEC_START)) hiding = true;
        if (!hiding2 && t.includes(CTX_START)) hiding2 = true;
        if (!hiding3 && t.includes(MB_CTX_START)) hiding3 = true;
        // Hide element
        if (hiding || hiding2 || hiding3) {
          el.style.setProperty('display', 'none', 'important');
          el.setAttribute('data-mbrain-sys', '1');
        }
        // Stop hiding
        if (hiding && t.includes(SPEC_END)) hiding = false;
        if (hiding2 && t.includes(CTX_END)) hiding2 = false;
        if (hiding3 && t.includes(MB_CTX_END)) hiding3 = false;
      }
    }

    const observer = new MutationObserver((mutations) => {
      const toSanitize = new Set();
      for (const mutation of mutations) {
        for (const added of mutation.addedNodes) {
          const addedTxt = added.textContent || '';
          const needsSanitize = addedTxt.includes(SPEC_START) || addedTxt.includes(MB_CTX_START) || addedTxt.includes(CTX_START);
          if (added.nodeType !== Node.ELEMENT_NODE || !needsSanitize) continue;
          let container = null;
          for (const sel of USER_MSG_SELECTORS) { if (added.matches?.(sel)) { container = added; break; } }
          if (!container) { let el = added.parentElement; for (let i = 0; i < 10 && el; i++) { for (const sel of USER_MSG_SELECTORS) { if (el.matches?.(sel)) { container = el; break; } } if (container) break; el = el.parentElement; } }
          if (container) { toSanitize.add(container); } else { let found = false; for (const sel of USER_MSG_SELECTORS) { for (const child of added.querySelectorAll(sel)) { if (child.textContent.includes(SPEC_START) || child.textContent.includes(CTX_START)) { toSanitize.add(child); found = true; } } } if (!found) toSanitize.add(added); }
        }
      }
      for (const el of toSanitize) sanitize(el);
      // Rescan all existing user messages (catches post-response React reconcile)
      for (const sel of USER_MSG_SELECTORS) {
        for (const el of document.querySelectorAll(sel)) { sanitize(el); }
      }
    });

    const start = () => observer.observe(document.body || document.documentElement, { childList: true, subtree: true });
    document.body ? start() : document.addEventListener('DOMContentLoaded', start);
  }

  injectAll();
  setupInputRelay();
  setupOutputRelay();
  setupBubbleSanitizer();
  // Listen for injection refresh requests from context-inject.js (MAIN world)
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    if (event.data?.source !== PREFIX) return;
    if (event.data?.type === PREFIX + ':request-injection') {
      const userMessage = event.data?.payload?.userMessage || '';
      refreshInjectionCache(userMessage);
    }
  });

  // Pre-warm injection cache on page load with empty query
  // This ensures __memoryExtInjection is populated before first message
  // Send storage mode to MAIN world on init
  chrome.storage.session.get('mb_storage_mode').then(r => {
    const mode = r.mb_storage_mode || 'local';
    window.postMessage({ source: PREFIX, type: `${PREFIX}:storage-mode`, payload: { mode } }, '*');
  }).catch(() => {});
  setTimeout(() => refreshInjectionCache(''), 1500);
  setTimeout(() => refreshInjectionCache(''), 5000); // second pass after backfill
  setInterval(refreshInjectionCache, 30000);

  console.debug('[MemBrain] Bridge v0.5.5 active on', window.location.hostname);
})();
